from taylorswift import PACKAGEDIR as taypackagedir
import numpy as np
import tkinter as tk
import csv, os

class taylorswiftGUI:
	def __init__(self):
		# load the data
		self.data = []
		with open(os.path.join(taypackagedir,'Grades.csv'),'rt') as f:
			self.data=[row for row in csv.reader(f,delimiter=',')]
		
		#initialize
		self.numsongs=149
		#relationship vector
		self.rel = [0]*4
		#happiness vector
		self.hap = [0]*3

		self.title=[0]*self.numsongs
		self.album=[0]*self.numsongs
		self.allhappy=np.zeros(self.numsongs)
		self.alldate=np.zeros(self.numsongs)
		self.selffeel=np.zeros(self.numsongs)
		self.glassfull=np.zeros(self.numsongs)
		self.stages=np.zeros(self.numsongs)
		self.tempo=np.zeros(self.numsongs)
		self.seriousness=np.zeros(self.numsongs)
		self.future=np.zeros(self.numsongs)
		self.malefeel=np.zeros(self.numsongs)
		self.together=np.zeros(self.numsongs)
		
		i=0
		for number in range(2,self.numsongs+2):
			self.set=self.data[number]
			self.title[i]=self.set[0]
			self.album[i]=self.set[1]
			self.allhappy[i]=float(self.set[2])
			self.alldate[i]=float(self.set[3])
			self.selffeel[i]=float(self.set[4])
			self.glassfull[i]=float(self.set[5])
			self.stages[i]=float(self.set[6])
			self.tempo[i]=float(self.set[7])
			self.seriousness[i]=float(self.set[8])
			self.future[i]=float(self.set[9])
			self.malefeel[i]=float(self.set[10])
			self.together[i]=float(self.set[11])
			i+=1
		# the answers for taytaysongs
		self.texts=np.loadtxt(os.path.join(taypackagedir, 'answertext.txt'),delimiter='#',dtype='str')
		# initialize the final list to empty
		self.finalok = [] 

	def ask_relationship(self):
		self.rel[0] = int(input("enter a number from 1-7: "))
	def ask_happiness(self):
		self.hap[0] = int(input("enter a number from 1-7:"))

	# calculates the perfect song based on the prior answers
	def calculate_song(self):
		# calculates each song's distance from the answer
		selferr=np.array([self.selffeel[i]-self.rel[0] for i in range(0,self.numsongs)])
		stageserr=np.array([self.stages[i]-self.rel[1] for i in range(0,self.numsongs)])
		seriouserr=np.array([self.seriousness[i]-self.rel[2] for i in range(0,self.numsongs)])
		futureerr=np.array([self.future[i]-self.rel[3] for i in range(0,self.numsongs)])
		maleerr=np.array([self.malefeel[i]-self.hap[0] for i in range(0,self.numsongs)])
		togethererr=np.array([self.together[i]-self.hap[1] for i in range(0,self.numsongs)])
		
		# seems to be the total distance from answer to song, or net error
		neterr=np.zeros(self.numsongs)
		for i in range(0,self.numsongs):
			neterr=selferr**2.+stageserr**2.+seriouserr**2.+futureerr**2.+maleerr**2.+togethererr**2.
		
		# list of songs where the error is between zero and 40, in order of error
		oklist=np.zeros(20)
		index=0
		n=0
		# refactored slightly to have clearer loop controls
		while n < 40 and index<5:
			if any(np.abs(neterr)==n):
				ok=np.where(np.abs(neterr)==n)[0]
				for x in ok:
					oklist[index]=x
					index+=1
			n+=1
		okintlist=[int(i) for i in oklist]
		self.finalok=okintlist[0:5]
	# compile the songs into a list, and print them (in test)
	def list_songs(self):
		for x,item in enumerate(self.finalok):
			n=x+1
			print(str(n)+': '+self.title[item])
			print(self.texts[item])
	# basically the original version but this time it's in an oop format
	def print_test(self):
		self.ask_relationship()
		self.ask_happiness()
		self.calculate_song()
		self.list_songs()


	# actually displays the gui
	def display_gui(self):
		return 0


tay = taylorswiftGUI()
tay.print_test()
